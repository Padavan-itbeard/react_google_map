# Google Maps in React

YouTube video can be found here: [https://youtu.be/Pf7g32CwX_s](https://youtu.be/Pf7g32CwX_s)

## Running Locally

Google Maps API Key: Create a new API key from the Google developer console, making sure that `Maps JavaScript API` has been enabled. Copy that key into your `.env.local` file creating an ENV var with the name `REACT_APP_GOOGLE_KEY`.